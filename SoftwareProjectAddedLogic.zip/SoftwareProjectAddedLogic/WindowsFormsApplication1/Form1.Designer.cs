﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.t8 = new System.Windows.Forms.PictureBox();
            this.t9 = new System.Windows.Forms.PictureBox();
            this.t10 = new System.Windows.Forms.PictureBox();
            this.t11 = new System.Windows.Forms.PictureBox();
            this.t12 = new System.Windows.Forms.PictureBox();
            this.t13 = new System.Windows.Forms.PictureBox();
            this.t7 = new System.Windows.Forms.PictureBox();
            this.t6 = new System.Windows.Forms.PictureBox();
            this.t1 = new System.Windows.Forms.PictureBox();
            this.t5 = new System.Windows.Forms.PictureBox();
            this.t4 = new System.Windows.Forms.PictureBox();
            this.t3 = new System.Windows.Forms.PictureBox();
            this.t2 = new System.Windows.Forms.PictureBox();
            this.foundations = new System.Windows.Forms.Panel();
            this.f4 = new System.Windows.Forms.PictureBox();
            this.f3 = new System.Windows.Forms.PictureBox();
            this.f2 = new System.Windows.Forms.PictureBox();
            this.f1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.t8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t2)).BeginInit();
            this.foundations.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.f4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.t8);
            this.panel1.Controls.Add(this.t9);
            this.panel1.Controls.Add(this.t10);
            this.panel1.Controls.Add(this.t11);
            this.panel1.Controls.Add(this.t12);
            this.panel1.Controls.Add(this.t13);
            this.panel1.Controls.Add(this.t7);
            this.panel1.Controls.Add(this.t6);
            this.panel1.Controls.Add(this.t1);
            this.panel1.Controls.Add(this.t5);
            this.panel1.Controls.Add(this.t4);
            this.panel1.Controls.Add(this.t3);
            this.panel1.Controls.Add(this.t2);
            this.panel1.Location = new System.Drawing.Point(26, 41);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(922, 534);
            this.panel1.TabIndex = 0;
            // 
            // t8
            // 
            this.t8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t8.Location = new System.Drawing.Point(65, 293);
            this.t8.Name = "t8";
            this.t8.Size = new System.Drawing.Size(126, 189);
            this.t8.TabIndex = 12;
            this.t8.TabStop = false;
            this.t8.Click += new System.EventHandler(this.t8_Click);
            // 
            // t9
            // 
            this.t9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t9.Location = new System.Drawing.Point(197, 293);
            this.t9.Name = "t9";
            this.t9.Size = new System.Drawing.Size(126, 189);
            this.t9.TabIndex = 11;
            this.t9.TabStop = false;
            this.t9.Click += new System.EventHandler(this.t9_Click);
            // 
            // t10
            // 
            this.t10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t10.Location = new System.Drawing.Point(329, 293);
            this.t10.Name = "t10";
            this.t10.Size = new System.Drawing.Size(126, 189);
            this.t10.TabIndex = 10;
            this.t10.TabStop = false;
            this.t10.Click += new System.EventHandler(this.t10_Click);
            // 
            // t11
            // 
            this.t11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t11.Location = new System.Drawing.Point(461, 293);
            this.t11.Name = "t11";
            this.t11.Size = new System.Drawing.Size(126, 189);
            this.t11.TabIndex = 9;
            this.t11.TabStop = false;
            this.t11.Click += new System.EventHandler(this.t11_Click);
            // 
            // t12
            // 
            this.t12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t12.Location = new System.Drawing.Point(593, 293);
            this.t12.Name = "t12";
            this.t12.Size = new System.Drawing.Size(126, 189);
            this.t12.TabIndex = 8;
            this.t12.TabStop = false;
            this.t12.Click += new System.EventHandler(this.t12_Click);
            // 
            // t13
            // 
            this.t13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t13.Location = new System.Drawing.Point(725, 293);
            this.t13.Name = "t13";
            this.t13.Size = new System.Drawing.Size(126, 189);
            this.t13.TabIndex = 7;
            this.t13.TabStop = false;
            this.t13.Click += new System.EventHandler(this.t13_Click);
            // 
            // t7
            // 
            this.t7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t7.Location = new System.Drawing.Point(793, 45);
            this.t7.Name = "t7";
            this.t7.Size = new System.Drawing.Size(126, 189);
            this.t7.TabIndex = 6;
            this.t7.TabStop = false;
            this.t7.Click += new System.EventHandler(this.t7_Click);
            // 
            // t6
            // 
            this.t6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t6.Location = new System.Drawing.Point(661, 45);
            this.t6.Name = "t6";
            this.t6.Size = new System.Drawing.Size(126, 189);
            this.t6.TabIndex = 5;
            this.t6.TabStop = false;
            this.t6.Click += new System.EventHandler(this.t6_Click);
            // 
            // t1
            // 
            this.t1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t1.Location = new System.Drawing.Point(3, 45);
            this.t1.Name = "t1";
            this.t1.Size = new System.Drawing.Size(126, 189);
            this.t1.TabIndex = 2;
            this.t1.TabStop = false;
            this.t1.Click += new System.EventHandler(this.t1_Click);
            // 
            // t5
            // 
            this.t5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t5.Location = new System.Drawing.Point(529, 45);
            this.t5.Name = "t5";
            this.t5.Size = new System.Drawing.Size(126, 189);
            this.t5.TabIndex = 4;
            this.t5.TabStop = false;
            this.t5.Click += new System.EventHandler(this.t5_Click);
            // 
            // t4
            // 
            this.t4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t4.Location = new System.Drawing.Point(397, 45);
            this.t4.Name = "t4";
            this.t4.Size = new System.Drawing.Size(126, 189);
            this.t4.TabIndex = 3;
            this.t4.TabStop = false;
            this.t4.Click += new System.EventHandler(this.t4_Click);
            // 
            // t3
            // 
            this.t3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t3.Location = new System.Drawing.Point(265, 45);
            this.t3.Name = "t3";
            this.t3.Size = new System.Drawing.Size(126, 189);
            this.t3.TabIndex = 1;
            this.t3.TabStop = false;
            this.t3.Click += new System.EventHandler(this.t3_Click);
            // 
            // t2
            // 
            this.t2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.t2.Location = new System.Drawing.Point(133, 45);
            this.t2.Name = "t2";
            this.t2.Size = new System.Drawing.Size(126, 189);
            this.t2.TabIndex = 0;
            this.t2.TabStop = false;
            this.t2.Click += new System.EventHandler(this.t2_Click);
            // 
            // foundations
            // 
            this.foundations.Controls.Add(this.f4);
            this.foundations.Controls.Add(this.f3);
            this.foundations.Controls.Add(this.f2);
            this.foundations.Controls.Add(this.f1);
            this.foundations.Location = new System.Drawing.Point(1193, 12);
            this.foundations.Name = "foundations";
            this.foundations.Size = new System.Drawing.Size(250, 827);
            this.foundations.TabIndex = 0;
            // 
            // f4
            // 
            this.f4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f4.Location = new System.Drawing.Point(69, 634);
            this.f4.Name = "f4";
            this.f4.Size = new System.Drawing.Size(126, 189);
            this.f4.TabIndex = 13;
            this.f4.TabStop = false;
            // 
            // f3
            // 
            this.f3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f3.Location = new System.Drawing.Point(69, 439);
            this.f3.Name = "f3";
            this.f3.Size = new System.Drawing.Size(126, 189);
            this.f3.TabIndex = 14;
            this.f3.TabStop = false;
            // 
            // f2
            // 
            this.f2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f2.Location = new System.Drawing.Point(69, 244);
            this.f2.Name = "f2";
            this.f2.Size = new System.Drawing.Size(126, 189);
            this.f2.TabIndex = 15;
            this.f2.TabStop = false;
            // 
            // f1
            // 
            this.f1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.f1.Location = new System.Drawing.Point(69, 29);
            this.f1.Name = "f1";
            this.f1.Size = new System.Drawing.Size(126, 189);
            this.f1.TabIndex = 16;
            this.f1.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(487, 734);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Reset";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1454, 920);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.foundations);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.t8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t2)).EndInit();
            this.foundations.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.f4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel foundations;
        private System.Windows.Forms.PictureBox t2;
        private System.Windows.Forms.PictureBox t7;
        private System.Windows.Forms.PictureBox t6;
        private System.Windows.Forms.PictureBox t5;
        private System.Windows.Forms.PictureBox t4;
        private System.Windows.Forms.PictureBox t3;
        private System.Windows.Forms.PictureBox t8;
        private System.Windows.Forms.PictureBox t9;
        private System.Windows.Forms.PictureBox t10;
        private System.Windows.Forms.PictureBox t11;
        private System.Windows.Forms.PictureBox t12;
        private System.Windows.Forms.PictureBox t13;
        private System.Windows.Forms.PictureBox t1;
        private System.Windows.Forms.PictureBox f4;
        private System.Windows.Forms.PictureBox f3;
        private System.Windows.Forms.PictureBox f2;
        private System.Windows.Forms.PictureBox f1;
        private System.Windows.Forms.Button button1;
    }
}

